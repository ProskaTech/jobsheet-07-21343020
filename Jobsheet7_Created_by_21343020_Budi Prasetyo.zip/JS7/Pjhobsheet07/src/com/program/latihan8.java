package com.program;
// Created by 21343020_Budi Prasetyo
// pernyataan do while
public class latihan8 {
    public static void main(String[] args) {
        
    int i=20;

    do{
        System.out.println(i);
        i++;
    }
    
    while(i<10);
    }
}

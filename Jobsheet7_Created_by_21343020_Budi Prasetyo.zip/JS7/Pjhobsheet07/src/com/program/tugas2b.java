package com.program;
// Created by 21343020_Budi Prasetyo
public class tugas2b {
    public static void main(String[] args) {
        int angka=20;

        while (angka>=1){
            System.out.println(angka);
            angka--;
        }
    }
}

package com.program;
// Created by 21343020_Budi Prasetyo
public class tugas2c {
    public static void main(String[] args) {
        int angka=20;

        do{
            System.out.println(angka);
            angka--;
        }
        while (angka>=1);

    }
}

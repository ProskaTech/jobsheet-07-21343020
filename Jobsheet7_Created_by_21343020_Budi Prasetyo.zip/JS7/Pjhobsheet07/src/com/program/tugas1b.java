package com.program;
// Created by 21343020_Budi Prasetyo
public class tugas1b {
    public static void main(String[] args) {
        int nama=0;

        while (nama<10){
            System.out.println("Budi");
            nama++;
        }
    }
}

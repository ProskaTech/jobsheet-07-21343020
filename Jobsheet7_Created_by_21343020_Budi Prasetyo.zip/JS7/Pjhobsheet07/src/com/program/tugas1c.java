package com.program;
// Created by 21343020_Budi Prasetyo
public class tugas1c {
    public static void main(String[] args) {
        int nama=0;

        do{
            System.out.println("Budi");
            nama++;
        }
        while (nama<10);

    }
}

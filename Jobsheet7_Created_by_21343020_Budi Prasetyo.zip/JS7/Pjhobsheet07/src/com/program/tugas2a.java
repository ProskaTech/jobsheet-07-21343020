package com.program;
// Created by 21343020_Budi Prasetyo
public class tugas2a {
    public static void main(String[] args) {

        int angka;
        for (angka=20; angka>=1; angka--){
        System.out.println(angka);
         }   
    }
}

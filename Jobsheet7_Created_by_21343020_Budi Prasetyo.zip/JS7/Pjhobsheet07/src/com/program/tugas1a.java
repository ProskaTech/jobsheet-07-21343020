package com.program;
// Created by 21343020_Budi Prasetyo
public class tugas1a {
    public static void main(String[] args) {

        int nama;
        for (nama=1; nama<=10; nama++){
        System.out.println("Budi");
         }   
    }
}

package com.program;
// Created by 21343020_Budi Prasetyo
// pernyataan for
public class latihan2 {
    public static void main(String[] args) {
        int bilangan;
        for (bilangan=60; bilangan>10; bilangan-=10)
        System.out.println(bilangan);

    }
}
